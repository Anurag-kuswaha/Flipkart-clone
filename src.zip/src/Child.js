
import React from 'react';
import ReactDOM from 'react-dom';
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
  integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l"
  crossorigin="anonymous"
/>

 export default  function  Body(props){
      const [name, setName]=React.useState('anurag')
        return   (
            <>
            <input type="text"> </input>
           <button onClick={()=>{
            props.updateValue("child is trigerring the event");
           }
          }
        > Click here </button>
        <h1> !!!!!!!!!!!!!!!!!!!this one is the header_ space!!!!!!!!!!!!!!!!!!!!!!!! </h1> 
            </> 
          )
}

//ReactDOM.render(<header_ />, document.getElementById('root'));
